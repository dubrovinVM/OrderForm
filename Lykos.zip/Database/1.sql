USE [lykos]
GO

INSERT INTO [dbo].[all_categories]
           ([form_part_cat_id]
           ,[name])
     VALUES
           (<form_part_cat_id, int,>
           ,<name, varchar(500),>)
GO

